clear all
close all
clc

H=tf(-4994.4,[1 723.95 1550 29488.24]);
nyquist(H);



