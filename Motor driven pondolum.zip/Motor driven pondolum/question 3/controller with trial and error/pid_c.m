clc
clear
close all

%% system
G = tf(-4994.4,[1 723.95 1550 29488.24]);
GC = tf([0.01 , -0.01] , 1);
systemm = G*GC;

figure()
step(systemm)
