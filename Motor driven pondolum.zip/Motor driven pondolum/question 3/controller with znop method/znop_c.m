clc
clear
close all

%% system
ts = 0.01;
TF = 30;
t = 0:ts:TF;
% s = tf('s');
% system = (-4994.4) / (s^3 + 723.95*s*s + 1030.55*s + 29488.24);
G = tf(-4994.4,[1 723.95 1550 29488.24]);

Gc = tf([-2.62 -131.26 -1640.75],[1 0]);

figure();

Tclp = feedback(G*Gc , 1);
step(Tclp , TF);

Info = stepinfo(Tclp);
OS = Info.Overshoot;
TS = Info.SettlingTime;
TR = Info.RiseTime;

grid on
xlabel('time(s)');
ylabel('amplitude');
title('controller with znop');
