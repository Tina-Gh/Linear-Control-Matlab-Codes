clc
clear
close all

G = tf(-4994.4 , [1 723.95 1550 29488.24]);
bode(G)