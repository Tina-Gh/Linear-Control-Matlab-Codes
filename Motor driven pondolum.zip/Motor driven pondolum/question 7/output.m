clc
clear
close all

%% system
G = tf(-4994.4,[1 723.95 1550 29488.24]);
GC = tf([-122.39 -1337.72 -2805.54] , [1 76.95 25.28]);
systemm = G*GC;

figure()
step(systemm)
